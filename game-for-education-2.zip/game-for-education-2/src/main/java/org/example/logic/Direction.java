package org.example.logic;

public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
